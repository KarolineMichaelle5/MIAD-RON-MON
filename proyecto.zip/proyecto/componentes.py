# custom_components.py
import numpy as np
from scipy.signal import savgol_filter
 
def preproc_fn(X):
    X = np.asarray(X)
    out = []
    for row in X:
        if len(row) > 15:
            out.append(savgol_filter(row, 15, 3, deriv=2))
        else:
            out.append(row)
    return np.vstack(out)