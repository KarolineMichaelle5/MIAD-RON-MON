from fastapi import FastAPI
from pydantic import BaseModel
import joblib
import numpy as np

# ---- Cargar modelo ----
MODEL_PATH = "mlp_ron_mon_modelo.joblib"
model = joblib.load(MODEL_PATH)

# ---- Crear API ----
app = FastAPI(
    title="API Modelo MLP Ron-Mon",
    description="API REST para realizar predicciones con el modelo MLP entrenado",
    version="1.0.0"
)

# ---- Definir la estructura de entrada ----
class InputData(BaseModel):
    features: list  # Lista con las características en el orden correcto

# ---- Endpoint de test ----
@app.get("/")
def root():
    return {"status": "API funcionando correctamente"}

# ---- Endpoint de predicción ----
@app.post("/predict")
def predict(data: InputData):
    try:
        # Convertir a array numpy
        X = np.array(data.features).reshape(1, -1)

        # Realizar predicción
        prediction = model.predict(X)

        return {
            "input": data.features,
            "prediction": prediction.tolist()
        }
    except Exception as e:
        return {"error": str(e)}
