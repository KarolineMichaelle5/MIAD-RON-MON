import os
import re
import tkinter as tk
from tkinter import filedialog, messagebox
from datetime import datetime
 
import pandas as pd
from joblib import load
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
 
# ------------------ CONFIGURACIÓN ------------------
# Modelo único con red + escaladores + nombres de variables
MODEL_JOBLIB = "mlp_ron_mon_modelo.joblib"
 
SPEC_RON_MIN = 84.0
 
# Colores Ecopetrol
BG = "#F4F5F4"      # fondo general suave
CARD_BG = "#FFFFFF" # fondo tarjetas
GREEN = "#184A2C"
FG = "#222"
 
plt.rcParams.update({
    "axes.edgecolor": "#888",
    "xtick.color": "#333",
    "ytick.color": "#333",
    "axes.labelcolor": "#333"
})
 
# ------------------ APP ------------------
root = tk.Tk()
root.title("Inferencia de RON/MON en Gasolinas")
root.configure(bg=BG)
root.geometry("1100x720")
 
# Hacer la grilla responsive (2 columnas x 3 filas)
root.grid_columnconfigure(0, weight=1, uniform="col")
root.grid_columnconfigure(1, weight=1, uniform="col")
root.grid_rowconfigure(1, weight=1, uniform="row")  # fila de tarjetas superiores
root.grid_rowconfigure(2, weight=1, uniform="row")  # fila de tarjetas inferiores
 
# ------------------ ENCABEZADO ------------------
header = tk.Frame(root, bg=BG)
header.grid(row=0, column=0, columnspan=2, sticky="nsew", padx=16, pady=(14, 6))
header.grid_columnconfigure(0, weight=1)
 
title = tk.Label(
    header,
    text="DEPARTAMENTO INSPECCIÓN DE CALIDAD\nINFERENCIA DE RON/MON EN GASOLINAS",
    font=("Arial", 18, "bold"),
    bg=BG, fg=GREEN,
    justify="center"
)
title.grid(row=0, column=0, sticky="n")
 
fecha_lbl = tk.Label(
    header,
    text=f"Fecha actual: {datetime.now().strftime('%d/%m/%Y')}",
    font=("Arial", 11),
    bg=BG, fg=FG,
    anchor="e", justify="right"
)
fecha_lbl.grid(row=0, column=1, sticky="ne", padx=8)
 
# ------------------ TARJETA MODELO (arriba-izquierda) ------------------
card_model = tk.Frame(root, bg=CARD_BG, bd=1, relief="groove")
card_model.grid(row=1, column=0, sticky="nsew", padx=(16, 8), pady=(6, 8))
 
tk.Label(
    card_model, text="MODELO",
    font=("Arial", 14, "bold"),
    bg=CARD_BG, fg=GREEN
).pack(anchor="w", padx=14, pady=(12, 6))
 
row = tk.Frame(card_model, bg=CARD_BG)
row.pack(fill="x", padx=14, pady=2)
tk.Label(row, text="Versión del modelo:", bg=CARD_BG, fg=FG,
         font=("Arial", 11)).pack(side="left")
tk.Label(row, text="2025.01", bg="#E9ECEF", fg=FG,
         font=("Arial", 11), padx=8, pady=2).pack(side="left", padx=8)
 
row = tk.Frame(card_model, bg=CARD_BG)
row.pack(fill="x", padx=14, pady=2)
tk.Label(row, text="Nombre del modelo:", bg=CARD_BG, fg=FG,
         font=("Arial", 11)).pack(side="left")
tk.Label(row, text="MLP_RONMON", bg="#E9ECEF", fg=FG,
         font=("Arial", 11), padx=8, pady=2).pack(side="left", padx=8)
 
btn_predict = tk.Button(
    card_model,
    text="Subir Excel y Inferir",
    bg=GREEN, fg="white",
    font=("Arial", 12, "bold"),
    width=22
)
btn_predict.pack(pady=14)
 
# ------------------ TARJETA ESPECTRO (arriba-derecha) ------------------
card_spec = tk.Frame(root, bg=CARD_BG, bd=1, relief="groove")
card_spec.grid(row=1, column=1, sticky="nsew", padx=(8, 16), pady=(6, 8))
 
tk.Label(
    card_spec, text="ESPECTRO CARGADO",
    font=("Arial", 14, "bold"),
    bg=CARD_BG, fg=GREEN
).pack(anchor="w", padx=14, pady=(12, 6))
 
spec_canvas_holder = None
 
# ------------------ TARJETA RESULTADOS (abajo-izquierda) ------------------
card_res = tk.Frame(root, bg=CARD_BG, bd=1, relief="groove")
card_res.grid(row=2, column=0, sticky="nsew", padx=(16, 8), pady=(8, 16))
 
tk.Label(
    card_res, text="RESULTADOS INFERIDOS",
    font=("Arial", 14, "bold"),
    bg=CARD_BG, fg=GREEN
).pack(anchor="w", padx=14, pady=(12, 6))
 
res_body = tk.Frame(card_res, bg=CARD_BG)
res_body.pack(fill="x", padx=14, pady=6)
 
lbl_id_title = tk.Label(
    res_body,
    text="Identificación de la muestra:",
    font=("Arial", 11),
    bg=CARD_BG, fg=FG
)
lbl_id_title.grid(row=0, column=0, sticky="w", padx=(0, 8), pady=2)
 
lbl_id_val = tk.Label(
    res_body,
    text="--",
    font=("Arial", 11),
    bg="#E9ECEF", fg=FG,
    padx=8, pady=2
)
lbl_id_val.grid(row=0, column=1, sticky="w", pady=2)
 
# KPIs
kpi = tk.Frame(card_res, bg=CARD_BG)
kpi.pack(fill="x", padx=14, pady=(8, 2))
 
lblR = tk.Label(
    kpi, text="RON\n--",
    font=("Arial", 18, "bold"),
    bg="#F8FBFF", fg=FG,
    bd=1, relief="solid",
    padx=18, pady=10
)
lblR.grid(row=0, column=0, padx=(0, 16))
 
lblM = tk.Label(
    kpi, text="MON\n--",
    font=("Arial", 18, "bold"),
    bg="#FFF8F0", fg=FG,
    bd=1, relief="solid",
    padx=18, pady=10
)
lblM.grid(row=0, column=1)
 
lblC = tk.Label(
    card_res,
    text="Cumple especificación: --",
    font=("Arial", 12, "bold"),
    bg=CARD_BG, fg=FG
)
lblC.pack(anchor="w", padx=14, pady=(10, 12))
 
# ------------------ TARJETA TENDENCIAS (abajo-derecha) ------------------
card_trend = tk.Frame(root, bg=CARD_BG, bd=1, relief="groove")
card_trend.grid(row=2, column=1, sticky="nsew", padx=(8, 16), pady=(8, 16))
 
tk.Label(
    card_trend, text="TENDENCIAS",
    font=("Arial", 14, "bold"),
    bg=CARD_BG, fg=GREEN
).pack(anchor="w", padx=14, pady=(12, 6))
 
trend_canvas_holder = None
ron_hist, mon_hist, date_hist = [], [], []
 
# ------------------ CARGAR MODELO ------------------
try:
    artefactos = load(MODEL_JOBLIB)
    model = artefactos["model"]
    scaler_X = artefactos["scaler_X"]
    scaler_y = artefactos["scaler_y"]
    feature_names = artefactos["feature_names"]  # orden de entrenamiento
except Exception as e:
    messagebox.showerror("Modelo", f"No se pudo cargar el modelo:\n{e}")
    root.destroy()
 
 
# ------------------ UTILIDADES ------------------
def num_from_header(h):
    """Extrae un número float desde un encabezado tipo '3931 cm-1'."""
    s = str(h).strip().replace(",", ".")
    m = re.search(r"[-+]?\d+(?:\.\d+)?", s)
    return float(m.group()) if m else None
 
 
def plot_in_card(frame, x, y, title, invert_x=False):
    plt.close('all')
    fig, ax = plt.subplots(figsize=(6.6, 3.1))
    ax.plot(x, y, linewidth=1.4, color=GREEN)
    ax.set_xlabel("Número de onda (cm⁻¹)")
    ax.set_ylabel("Absorbancia")
    ax.set_title(title, fontsize=11, pad=10)
    ax.grid(True, alpha=0.3)
    if invert_x:
        ax.invert_xaxis()
    plt.subplots_adjust(bottom=0.22)
    fig.tight_layout(pad=1.6)
    canvas = FigureCanvasTkAgg(fig, master=frame)
    canvas.get_tk_widget().pack(fill="both", expand=True, padx=12, pady=(0, 12))
    canvas.draw()
    return canvas
 
 
def plot_trends():
    global trend_canvas_holder
    if trend_canvas_holder:
        trend_canvas_holder.get_tk_widget().destroy()
        trend_canvas_holder = None
    if not ron_hist:
        return
    plt.close('all')
    fig, ax = plt.subplots(figsize=(6.6, 3.1))
    ax.plot(date_hist, ron_hist, marker="o", linewidth=1.4, label="RON")
    ax.plot(date_hist, mon_hist, marker="o", linewidth=1.4, label="MON")
    ax.set_xlabel("Fecha")
    ax.set_ylabel("Valor")
    ax.set_title("Histórico reciente", fontsize=11, pad=10)
    ax.grid(True, alpha=0.3)
    ax.legend()
    plt.xticks(rotation=30)
    plt.subplots_adjust(bottom=0.30)
    fig.tight_layout(pad=1.6)
    trend_canvas_holder = FigureCanvasTkAgg(fig, master=card_trend)
    trend_canvas_holder.get_tk_widget().pack(
        fill="both", expand=True, padx=12, pady=(0, 12)
    )
    trend_canvas_holder.draw()
 
 
# ------------------ PREDICCIÓN ------------------
def predecir():
    global spec_canvas_holder
 
    p = filedialog.askopenfilename(
        title="Seleccionar archivo Excel",
        filetypes=[("Excel", "*.xlsx;*.xls")]
    )
    if not p:
        return
 
    try:
        df0 = pd.read_excel(p)
 
        if df0.shape[1] < 2:
            raise ValueError("El archivo debe tener una columna ID y columnas de espectro.")
 
        # ID de muestra: toma la primera celda de la primera columna
        #sample_id = str(df0.iloc[0, 0])
        sample_id = os.path.basename(p)
        if not sample_id or sample_id.lower() == "nan":
            sample_id = os.path.basename(p)
        lbl_id_val.config(text=sample_id)
 
        # ------------------------------
        # MAPEO DE COLUMNAS DEL EXCEL
        # A LAS COLUMNAS DEL MODELO
        # ------------------------------
        orig_cols = list(df0.columns)
 
        # Mapa: wavenumber_int -> nombre de columna en el Excel
        wave_to_col = {}
        for c in orig_cols:
            n = num_from_header(c)
            if n is not None:
                wave_to_col[int(round(n))] = c
 
        # Construir lista de columnas en el mismo orden de feature_names
        df_model_cols = []
        missing = []
 
        for fname in feature_names:
            if fname in orig_cols:
                # Coincidencia exacta (por ejemplo 'IDENT' o '3931 cm-1')
                df_model_cols.append(fname)
            else:
                n = num_from_header(fname)
                if n is not None:
                    key = int(round(n))
                    if key in wave_to_col:
                        df_model_cols.append(wave_to_col[key])
                    else:
                        missing.append(fname)
                else:
                    # columna no numérica que no está en el Excel
                    missing.append(fname)
 
        if missing:
            raise ValueError(
                "El archivo no contiene todas las columnas esperadas del modelo.\n"
                f"Faltan, por ejemplo: {missing[:10]}"
            )
 
        # DataFrame ya alineado con el orden del modelo
        df_model = df0[df_model_cols].copy()
 
        # ------------------------------
        # PREDICCIÓN
        # ------------------------------
        x = df_model.iloc[0:1, :].values
        x_s = scaler_X.transform(x)
        y_pred_s = model.predict(x_s)
        y_pred = scaler_y.inverse_transform(y_pred_s)
 
        ron = float(y_pred[0, 0])
        mon = float(y_pred[0, 1])
 
        # KPIs y cumplimiento
        if ron >= SPEC_RON_MIN:
            lblR.config(text=f"RON\n{ron:.1f}", fg=GREEN, bg="#F1FAF3")
            lblC.config(text="Cumple especificación: SÍ ✅", fg=GREEN)
        else:
            lblR.config(text=f"RON\n{ron:.1f}", fg="red", bg="#FFF5F5")
            lblC.config(text="Cumple especificación: NO ❌", fg="red")
 
        lblM.config(text=f"MON\n{mon:.1f}", fg=GREEN)
 
        # ------------------------------
        # ESPECTRO EN TARJETA DERECHA
        # ------------------------------
        if spec_canvas_holder:
            spec_canvas_holder.get_tk_widget().destroy()
            spec_canvas_holder = None
 
        # columnas espectrales (las que tienen número)
        spec_cols = [c for c in df_model_cols if num_from_header(c) is not None]
        x_axis = [num_from_header(c) for c in spec_cols]
        y_spec = df_model.iloc[0][spec_cols].values
 
        spec_canvas_holder = plot_in_card(
            card_spec, x_axis, y_spec,
            title=os.path.basename(p),
            invert_x=False
        )
 
        # ------------------------------
        # TENDENCIAS
        # ------------------------------
        ron_hist.append(ron)
        mon_hist.append(mon)
        date_hist.append(datetime.now().strftime("%d/%m"))
 
        if len(ron_hist) > 30:
            ron_hist.pop(0)
            mon_hist.pop(0)
            date_hist.pop(0)
 
        plot_trends()
 
        # Actualizar fecha en encabezado
        fecha_lbl.config(
            text=f"Fecha actual: {datetime.now().strftime('%d/%m/%Y %H:%M')}"
        )
 
    except Exception as e:
        messagebox.showerror("Predicción", str(e))
 
 
btn_predict.config(command=predecir)
 
# ------------------ RUN ------------------
root.mainloop() 